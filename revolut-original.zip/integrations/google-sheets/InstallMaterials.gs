/** PRIVATE instructor installer. Add to the same bound Apps Script project as Code.gs.
 * Run installRoundMaterials once as the owner of these Google Docs, then redeploy the web app.
 * Never paste this file into Tilda or publish it in GitHub. No sharing permissions are changed.
 */
function installRoundMaterials() {
  var registry = {
  "indonesia": {
    "R1": "1dg01BNhPcO9Og9lELIZE4RqFbsWtiqiSn8inuOnfviI",
    "R2": "1gqkHg7bmLyIzaQddSq0rtku5B4GERf2mb3yFEMxSbQc",
    "R2.interview": "1MuhLRvNZuIlRI5OKxNfP731-xcwZHGgQsxDtI_kZ82s",
    "R2.prototype": "1TW2Fa4tZGpR1xKnDKpF7CeDupCFvX2ybGJ6FHuUxB48",
    "R3": "1StmW8hK0_MEaD6_pfVYc9Sd6hhEHtaS9xPbeJvqr2Hc",
    "R4": "1ftSoaW1o1vjiEF9DupuEl9209ra4_bYTw6YVJJc9i3c",
    "R4.verify": "11U-LM2lYMSZ-ReLDuYlD2NeEzP57bF-vFj9XPj4MNFA",
    "R5": "1hWxaUno301vZAk0_uJWo4So5-jhRwSQWmaaH6OLJjWg",
    "R5.narrow": "1_InriMigHBX4gcbKRDm4Ks1Jz0DGFZE0bTb7JCgmZG8",
    "R5.diligence": "17QU6cNDaAWneuyvT5L5gslPwzGt7H_rr6xIeoKE3Kss",
    "R6": "1naoOVV1ilJ_G5_fN54V4r7c9lxeFG_199pbFhveloGI",
    "R6.B": "1xxmaIHckiwKTztU4etRY36rOYrb46cBGxwOrbkw6iog",
    "R7": "1DLGWMcuutiIIOjHpuwPPX-el5hWmokyy71NY2PgIHjo"
  },
  "philippines": {
    "R1": "1DBUcw7ROgHWSlZjWg-MKa2U7NnvsbrZmKseadHJAfL4",
    "R2": "1k_CWvyJhZ3VKlI8PstWX4P6virFxUsSbTGkVpTQScxQ",
    "R2.interview": "1D-HcoXaY7oUFPFiXPRKEg1LPuycbaEbHs7VtzuzNAkY",
    "R2.prototype": "1ci6Hu-mfZ7Ofwjguv9rVMVjurrAVupD6di8AneIYPf4",
    "R3": "1waMzPEQOxHiCuBuKaVKAqDj1Te1nXTc5L00fwLAzgYc",
    "R4": "1jGe4oZkg9IGYmKVexn87fioLneOfO2yLlnjJ1Ips2Sc",
    "R4.verify": "1r6uOn0saRdOuvCwzn49r31F9auE9oIQ5RyYxie_H4vA",
    "R5": "1fI0-fcqlQlpte947ezwG2Cx0wuX6gasgS01WCJ9sMrI",
    "R5.narrow": "1p7L91Rv5aq4264Hr6GRlQf9vFNi2_fvh0-yTdxGiquQ",
    "R5.diligence": "1TiKEjNj0obpt4rFmOVLbTLsSUvYVa9AEsaAgZaOXQQw",
    "R6": "1bEMFkpm6EXwivZAQJtrFqMuMXxit3wYHDR60PS1EDWI",
    "R6.B": "1R0Obw0s4FbK5HNZ5r49EV6PYdWOmaAu7pCUfo2AO0N4",
    "R7": "1nXn-Qat6Cx8eO6G3eRJr_HWSsLX3f4BJeeRx5XajfaE"
  },
  "thailand": {
    "R1": "1JwO0DwgXtYuByDDj1Y_VdgJnEv40CgJZlWTms8cCdsc",
    "R2": "1JEjjYxmb3OuThBVBpbCXlSV5C91YDl8oyBgBz719ArM",
    "R2.interview": "1PtISn-oY04t-JrlXjrWjnKOqw1qqkkWSGTK3uV0Eib0",
    "R2.prototype": "1lMv116riJxmOhjxc3d4KDBEd0XrW3W8OdTNpoGq4AaM",
    "R3": "1-fsnL8OJggQdVMFTY_VWLLCpppn8KPVXlpCJWyYSKm0",
    "R4": "1elkUA-10Fi2FSHnkiCMOAtUGd4GetfVrZ13FKv6eJ_A",
    "R4.verify": "1jSl9xDDFCYg0cS9cPP1AFYVzBsyaJ37SDJXmDhLul90",
    "R5": "1S6abd0n_BtDj_8K2O_iJGy3Mw2ZoWsJaDY6jzzTKWsA",
    "R5.narrow": "13DtuVcRafBkORqm7dsRKS6PBylkuYCXx2_xC3B0rI9Q",
    "R5.diligence": "1JZiXkb98zyizIOXy-jwrNgYjfN84ID7glj6iT2kV0KI",
    "R6": "1jVN55p5WBSLrv24Dwzzb9NtYLOhwqiMbpyJaCn2mFz4",
    "R6.B": "1zDyAF4-ojG1n0Z6tx1mEAmN6UVDyd2u6I5aQ7_TYc2E",
    "R7": "17irQVHMk9sSW7ex03CQcXcgvt8Wlek2ZfZwzu40Omds"
  },
  "vietnam": {
    "R1": "10CpOU4v5FZLOBLnqk8BhCKPblhbH_Ae6eybV3z5RFSk",
    "R2": "1j1XKIS9GlUCisG_IbRMuYU6e9_1YUfxNV0PaTA6YWdc",
    "R2.interview": "1pVevlKWrecGSeSCtwGTRn1z_5ijOc-bxns1YZrEz47w",
    "R2.prototype": "1awvXikq-S2kmOgsjYWAYGARK__IicHvAf278I0Einsg",
    "R3": "1mUda4sf0hkXnYNfJ5x050r8CoJARI5ACpUIWkBrdKz0",
    "R4": "18URflkTt-Sn1ofUpPTKD5hwdZebVdxFN-dKrSKiqc54",
    "R4.verify": "1MB_5xJXQsRJWpzF4SzRTbXnIKbq1hwRePhgqpdBgHfQ",
    "R5": "1zwAVC-7Ujv-oD3NQCuH9l4o4wM5gFbu6tfHe4dI9kE0",
    "R5.narrow": "1IOxpX4teBXV0vh_gDmpSvWyJpFSlPZbkAGkeWNC2OPg",
    "R5.diligence": "1bajqP8Nsc14fAKzJjdZpvJk0ghc89PRAp15XJ3pTROg",
    "R6": "1kjHmsRnC5SSo_0gjxwv0hj6QXfaY2qMWrzeX4hG5qfc",
    "R6.B": "1BwS6BmAe0FqPNdzA0B2yaWi0D6wCpzXyvrqD796g-kU",
    "R7": "1dup3IPO1XCHngrI15SaxWhsw1cGIUOqOvfg2bBdSlu8"
  }
};
  var count = 0;
  for (var market in registry) {
    for (var key in registry[market]) {
      var file = DriveApp.getFileById(registry[market][key]);
      if (file.getMimeType() !== "application/vnd.google-apps.document") throw new Error("Expected Google Doc: " + market + "/" + key);
      file.getName();
      count++;
    }
  }
  if (count !== 52) throw new Error("Expected 52 round documents");
  PropertiesService.getScriptProperties().setProperty("ROUND_MATERIALS", JSON.stringify(registry));
  console.log("Installed " + count + " private round documents. Redeploy a new web app version.");
}
